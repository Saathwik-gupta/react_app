This file has moved [here](https://github.com/facebook/create-react-app/blob/main/packages/cra-template-typescript/template/README.md)
