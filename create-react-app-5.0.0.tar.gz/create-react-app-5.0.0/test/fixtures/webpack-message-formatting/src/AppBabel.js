import React, { Component } from 'react';

class App extends Component {
  render() {
    return (
      <div>
        <span>
      </div>
    );
  }
}

export default App;
